﻿namespace ServerKlient
{
    partial class ClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxInkorg = new System.Windows.Forms.TextBox();
            this.tbxMeddelande = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSkicka = new System.Windows.Forms.Button();
            this.btnAnslut = new System.Windows.Forms.Button();
            this.tbxAnvändarnamn = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbxInkorg
            // 
            this.tbxInkorg.Location = new System.Drawing.Point(8, 75);
            this.tbxInkorg.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbxInkorg.Multiline = true;
            this.tbxInkorg.Name = "tbxInkorg";
            this.tbxInkorg.ReadOnly = true;
            this.tbxInkorg.Size = new System.Drawing.Size(252, 335);
            this.tbxInkorg.TabIndex = 0;
            // 
            // tbxMeddelande
            // 
            this.tbxMeddelande.Location = new System.Drawing.Point(8, 437);
            this.tbxMeddelande.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbxMeddelande.Name = "tbxMeddelande";
            this.tbxMeddelande.Size = new System.Drawing.Size(252, 26);
            this.tbxMeddelande.TabIndex = 2;
            this.tbxMeddelande.TextChanged += new System.EventHandler(this.tbxMeddelande_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 412);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Skicka ett meddelande";
            // 
            // btnSkicka
            // 
            this.btnSkicka.Location = new System.Drawing.Point(13, 473);
            this.btnSkicka.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSkicka.Name = "btnSkicka";
            this.btnSkicka.Size = new System.Drawing.Size(247, 55);
            this.btnSkicka.TabIndex = 4;
            this.btnSkicka.Text = "Skicka";
            this.btnSkicka.UseVisualStyleBackColor = true;
            this.btnSkicka.Click += new System.EventHandler(this.btnSkicka_Click_1);
            // 
            // btnAnslut
            // 
            this.btnAnslut.BackColor = System.Drawing.Color.Aqua;
            this.btnAnslut.Location = new System.Drawing.Point(169, 9);
            this.btnAnslut.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAnslut.Name = "btnAnslut";
            this.btnAnslut.Size = new System.Drawing.Size(139, 56);
            this.btnAnslut.TabIndex = 5;
            this.btnAnslut.Text = "Anslut";
            this.btnAnslut.UseVisualStyleBackColor = false;
            this.btnAnslut.Click += new System.EventHandler(this.btnAnslut_Click_1);
            // 
            // tbxAnvändarnamn
            // 
            this.tbxAnvändarnamn.Location = new System.Drawing.Point(8, 39);
            this.tbxAnvändarnamn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbxAnvändarnamn.Name = "tbxAnvändarnamn";
            this.tbxAnvändarnamn.Size = new System.Drawing.Size(153, 26);
            this.tbxAnvändarnamn.TabIndex = 6;
            this.tbxAnvändarnamn.TextChanged += new System.EventHandler(this.tbxAnvändarnamn_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Användarnamn";
            // 
            // ClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(332, 571);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbxAnvändarnamn);
            this.Controls.Add(this.btnAnslut);
            this.Controls.Add(this.btnSkicka);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbxMeddelande);
            this.Controls.Add(this.tbxInkorg);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "ClientForm";
            this.Text = "ClientForm";
            this.Load += new System.EventHandler(this.ClientForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxInkorg;
        private System.Windows.Forms.TextBox tbxMeddelande;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSkicka;
        private System.Windows.Forms.Button btnAnslut;
        private System.Windows.Forms.TextBox tbxAnvändarnamn;
        private System.Windows.Forms.Label label3;
    }
}