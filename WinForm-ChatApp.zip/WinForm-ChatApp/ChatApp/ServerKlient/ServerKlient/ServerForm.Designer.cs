﻿namespace ServerKlient
{
    partial class ServerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxInkorg = new System.Windows.Forms.TextBox();
            this.btnStarta = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbxInkorg
            // 
            this.tbxInkorg.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tbxInkorg.Location = new System.Drawing.Point(13, 53);
            this.tbxInkorg.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbxInkorg.Multiline = true;
            this.tbxInkorg.Name = "tbxInkorg";
            this.tbxInkorg.ReadOnly = true;
            this.tbxInkorg.Size = new System.Drawing.Size(284, 459);
            this.tbxInkorg.TabIndex = 0;
            // 
            // btnStarta
            // 
            this.btnStarta.BackColor = System.Drawing.Color.Aqua;
            this.btnStarta.Location = new System.Drawing.Point(13, 522);
            this.btnStarta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnStarta.Name = "btnStarta";
            this.btnStarta.Size = new System.Drawing.Size(284, 94);
            this.btnStarta.TabIndex = 1;
            this.btnStarta.Text = "Starta Server";
            this.btnStarta.UseVisualStyleBackColor = false;
            this.btnStarta.Click += new System.EventHandler(this.btnStarta_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(85, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Chat Logs";
            // 
            // ServerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 635);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnStarta);
            this.Controls.Add(this.tbxInkorg);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "ServerForm";
            this.Text = "ServerForm";
            this.Load += new System.EventHandler(this.ServerForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxInkorg;
        private System.Windows.Forms.Button btnStarta;
        private System.Windows.Forms.Label label1;
    }
}